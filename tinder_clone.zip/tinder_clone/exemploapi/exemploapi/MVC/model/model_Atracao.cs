﻿namespace exemploapi.MVC.model
{
    public class Atracao
    {
        public int Id { get; set; }
        public Genero? genero { get; set; }
    }
}
