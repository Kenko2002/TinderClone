﻿namespace exemploapi.MVC.model
{
    public class Localizacao
    {
        public int Id { get; set; }
        public float latitude { get; set; }
        public float longitude { get; set; }

    }

}
