﻿namespace exemploapi.MVC.model
{
    public class Genero
    {

            public int Id { get; set; }
            public string? nome { get; set; }

    }
}
