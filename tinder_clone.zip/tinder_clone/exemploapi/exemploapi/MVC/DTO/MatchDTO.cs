﻿namespace exemploapi.MVC.DTO
{
    public class MatchDTO
    {
        public int id_user_requisitado { get; set; }
    }
}
